﻿/*+----------------------------------------------------------------------
 ||           Abstract Class Game, Class War
 ||
 ||         Author:  Kimberly Gillespie
 ||        Created:  July 7, 2019
 ||  Last Modified:  July 9, 2019
 ||   Modification:  Cleanup, troubleshooting, and added comments.
 ||    
 ||        Purpose:  For the use of playing digital versions of card games, key objects are encapsulated here:
 ||                    Game - An outline of basic functions needed to play any game.
 ||                    War - Contains all functionality needed to play the card game War.
 ++-----------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Linq;

namespace War
{
    public abstract class Game
    {
        #region Abstract Methods

        public abstract void Start();
        public abstract void Play();
        public abstract void Finish();
        public abstract bool AskYN(string question);
        public abstract bool AnyKeyToContinue();

        #endregion
    }

    public class War : Game
    {
        #region Fields / Properties

        private WarDeck _deck = new WarDeck();
        private PlayerDeck _human = new PlayerDeck();
        private PlayerDeck _computer = new PlayerDeck();

        const bool WINNER_HUMAN = true;
        const bool WINNER_COMPUTER = false;

        public WarDeck Deck { get => _deck; set => _deck = value; }
        public PlayerDeck Human { get => _human; set => _human = value; }
        public PlayerDeck Computer { get => _computer; set => _computer = value; }

        #endregion

        #region Methods - Game Lifecycle

        // Start - Explain the game if needed.  Build, shuffle, and deal the deck, and then begin play.
        public override void Start()
        {
            bool replyYes;

            replyYes = AskYN("Do you know the rules?");

            if (!replyYes)
            {
                Console.WriteLine(Environment.NewLine + "HOW TO PLAY WAR:" + Environment.NewLine +
                    "    1. One 52-card deck is shuffled and dealt equally between two players." + Environment.NewLine +
                    "    2. Both place their top card face-up on the table." + Environment.NewLine +
                    "    3. The player with the higher card collects both cards and places them at the bottom of their deck. (Aces are high.)" + Environment.NewLine +
                    "    4. If the cards are equal, the players go to war:" + Environment.NewLine +
                    "        a. Both place three cards face-down on the table." + Environment.NewLine +
                    "        b. Then, both place one card face-up." + Environment.NewLine +
                    "        c. The player with the higher final card collects all cards on the table." + Environment.NewLine +
                    "        d. If the final card is equal, go to war again." + Environment.NewLine +
                    "        e. If one player doesn't have enough cards for war, use only as many cards as is possible." + Environment.NewLine +
                    "        f. If war occurs on a player's final card, that player loses.");
            }

            Console.WriteLine(Environment.NewLine + "*****************************************************");
            Console.WriteLine("Let's get started!");

            Deck.Build();

            Deck.Shuffle();
            Deck.Shuffle(); // for good measure

            (Human.Cards, Computer.Cards) = Deck.Deal();

            Play();
        }

        // Play - Update the player on the card counts.  Check if either has lost.  If not, both play a card face-up.  Compare those cards.
        public override void Play()
        {
            AnyKeyToContinue();

            if (Human.Cards.Count > 0 && Computer.Cards.Count > 0)  // Neither has lost yet.
            {
                if (Human.CardsInPlay.Count == 0) // This indicates we aren't mid-war.  Only update the player at the start of a new round.
                {
                    Console.WriteLine();
                    Console.WriteLine("You have " + Human.Cards.Count() + " cards.  The computer has " + Computer.Cards.Count() + " cards.");
                }

                Human.PlayTopCard(true);
                Computer.PlayTopCard(true);

                Console.WriteLine("(You:)  " + Human.CardInPlay.Display + "  vs  " + Computer.CardInPlay.Display + "  (:Computer)");

                CompareCards();
            }
            else
            {
                Finish();
            }
        }

        // Finish - Inform the player who won, then ask if they'd like to play again.
        public override void Finish()
        {
            Console.WriteLine(Environment.NewLine + "*****************************************************");
            Console.WriteLine("***************  G A M E   O V E R !  ***************");

            if (Human.Cards.Count == 0)
                Console.Write("Sorry, you lost!");
            else if (Computer.Cards.Count == 0)
                Console.Write("Hurray!!  You won!!");
            else
                Console.Write("?!? Something went wrong with the programming. ?!?");

            Console.WriteLine(Environment.NewLine);
            if (AskYN("Would you like to play again?"))
            {
                Deck.Cards.Clear();
                Human.Cards.Clear();
                Human.CardsInPlay.Clear();
                Computer.Cards.Clear();
                Computer.CardsInPlay.Clear();

                Start();
            }
            else
                Console.WriteLine(Environment.NewLine + "Thanks for playing! Bye-bye!");
        }

        #endregion

        #region Methods - User Input

        // Display a yes/no question. Keeps asking until it gets a valid answer.
        public override bool AskYN(string question)
        {
            string reply;

            Console.Write(question + " (Y/N) ");
            reply = Console.ReadLine();

            reply.Trim();

            if (reply == "Y" || reply == "y")
                return true;
            else if (reply == "N" || reply == "n")
                return false;
            else
                return AskYN(question);
        }

        // User presses any key to continue play.
        public override bool AnyKeyToContinue()
        {
            ConsoleKeyInfo anyKey = Console.ReadKey();
            return true;
        }

        #endregion

        #region Methods - Gameplay

        // Compare the values of the two cards in play.
        private void CompareCards()
        {
            // Human Wins
            if (Human.CardInPlay.Value > Computer.CardInPlay.Value)
            {
                Console.Write("YOU WIN!!!");

                if (Human.CardsInPlay.Count > 1)    // Indicates this is ending a war.
                    ShowWarCards(WINNER_HUMAN);
                else
                    Console.WriteLine();

                ReassignCards(WINNER_HUMAN);
                AnyKeyToContinue();
            }
            // Computer Wins
            else if (Computer.CardInPlay.Value > Human.CardInPlay.Value)
            {
                Console.Write("You lose.");

                if (Human.CardsInPlay.Count > 1)    // Indicates this is ending a war.
                    ShowWarCards(WINNER_COMPUTER);
                else
                    Console.WriteLine();

                ReassignCards(WINNER_COMPUTER);
                AnyKeyToContinue();
            }
            // Tie
            else
            {
                Console.WriteLine("WAR!");

                GoToWar();
            }
        }

        // Reassign the InPlay cards to the winner. Clear both InPlay decks and Play() again.
        private void ReassignCards(bool humanWon)
        {
            if (humanWon)
            {
                Human.ReturnInPlayCardsToDeck();
                Human.AddNewCards(Computer.CardsInPlay);
                Computer.CardsInPlay.Clear();
            }
            else // Computer won
            {
                Computer.ReturnInPlayCardsToDeck();
                Computer.AddNewCards(Human.CardsInPlay);
                Human.CardsInPlay.Clear();
            }

            Play();
        }

        // To break a tie, go to War - by placing 3 cards face-down, then resuming Play().
        private void GoToWar()
        {
            // Both players need 4 cards minimum to go to war.
            if (Human.Cards.Count >= 4 && Computer.Cards.Count >= 4)
            {
                for (int i = 0; i < 3; i++)
                {
                    Human.PlayTopCard(false);
                    Computer.PlayTopCard(false);
                }

                Console.WriteLine("(You:)  " + DisplayCards(Human.CardsInPlay) + "vs  " + DisplayCards(Computer.CardsInPlay) + "(:Computer)");

                Play();
            }
            // A player doesn't have enough cards.  Do an abbreviated war.
            else
            {
                // Play only as many cards as the losing player has.
                int numCardsLeft;
                if (Human.Cards.Count < Computer.Cards.Count)
                    numCardsLeft = Human.Cards.Count;
                else
                    numCardsLeft = Computer.Cards.Count;

                // Only do a face-down war if at least 2 cards.  (The last card must be saved for Play() where it's played face-up.)
                if (numCardsLeft >= 2)
                {
                    for (int i = 0; i < (numCardsLeft - 1); i++)
                    {
                        Human.PlayTopCard(false);
                        Computer.PlayTopCard(false);
                    }

                    Console.WriteLine("(You:)  " + DisplayCards(Human.CardsInPlay) + "vs  " + DisplayCards(Computer.CardsInPlay) + "(:Computer)");

                    Play();
                }
                // Skip war.
                else if (numCardsLeft == 1)
                {
                    Play();
                }
                // No cards left.  Game over.
                else
                {
                    Finish();
                }
            }
        }

        // After a War is decided, display the cards that were face-down.
        private void ShowWarCards(bool humanWon)
        {
            foreach (var card in Human.CardsInPlay)
                card.FaceUp = true;
            foreach (var card in Computer.CardsInPlay)
                card.FaceUp = true;

            if (humanWon)
                Console.Write(" You Kept: " + DisplayCards(Human.CardsInPlay));
            else // computer won
                Console.Write(" You Lost: " + DisplayCards(Human.CardsInPlay));

            if (humanWon)
                Console.Write("& You Gained: " + DisplayCards(Computer.CardsInPlay));
            else // computer won
                Console.Write("& Missed Out On: " + DisplayCards(Computer.CardsInPlay));

            Console.WriteLine();
        }

        // Returns a string of a List of cards.
        private string DisplayCards(List<PlayingCard> displayCards)
        {
            string display = "";

            foreach (var card in displayCards)
                display += card.Display + "  ";

            return display;
        }

        #endregion
    }
}