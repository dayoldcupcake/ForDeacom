﻿/*+----------------------------------------------------------------------
 ||           Classes PlayingCard, Deck, WarDeck, PlayerDeck
 ||
 ||         Author:  Kimberly Gillespie
 ||        Created:  July 7, 2019
 ||  Last Modified:  July 9, 2019
 ||   Modification:  Cleanup, troubleshooting, and added comments.
 ||    
 ||        Purpose:  For the use of playing digital versions of card games, key objects are encapsulated here:
 ||                    PlayingCard - A single Bicycle-style playing card.
 ||                           Deck - A single 52-card deck of cards, without Jokers. (Can be easily adjusted in future for multiple decks.)
 ||                        WarDeck - A single 52-card deck with the values and functions needed for the game War. (Linear values and an even 2-player deal.)
 ||                     PlayerDeck - A deck as kept by a single player.  Can be broken into a sub-deck for cards in play.
 ++-----------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

namespace War
{
    public class PlayingCard
    {
        #region Fields / Properties

        private char _suit;
        private string _rank;   // As displayed, ie "9" or "Q"
        private int _value;     // Assigned numerical value, set by game
        private bool _faceUp;

        public static readonly char[] Suits = new char[4] { '♥', '♦', '♣', '♠' };
        public static readonly string[] Ranks = new string[13] { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };

        public char Suit { get => _suit; set => _suit = value; }
        public string Rank { get => _rank; set => _rank = value; }
        public int Value { get => _value; set => _value = value; }
        public bool FaceUp { get => _faceUp; set => _faceUp = value; }

        public string Display
        {
            get
            {
                if (FaceUp)
                    return "[" + Rank + Suit + "]";
                else
                    return "[??]";
            }
        }

        #endregion

        #region Constructors

        public PlayingCard(char suit, string rank)
        {
            Console.OutputEncoding = Encoding.UTF8; // Required to print suit ASCII.

            _suit = suit;
            _rank = rank;
        }

        public PlayingCard(char suit, string rank, int value) : this(suit, rank)
        {
            _value = value;
            _faceUp = false;
        }

        #endregion
    }

    public class Deck
    {
        #region Fields / Properties

        private List<PlayingCard> _cards = new List<PlayingCard>();

        public List<PlayingCard> Cards { get => _cards; set => _cards = value; }

        #endregion

        #region Constructors / Methods

        public Deck()
        {
        }

        // Build one 52-card deck.
        public virtual void Build()
        {
            foreach (var suit in PlayingCard.Suits)         // Four Suits
                foreach (var rank in PlayingCard.Ranks)     // 13 Ranks
                    Cards.Add(new PlayingCard(suit, rank));
        }

        // Randomize the order of the list (ie shuffle the cards) with Fisher-Yates.
        public void Shuffle()
        {
            Random randomNum = new Random();
            PlayingCard tempCard;
            int numCards, numNext;

            numCards = _cards.Count;

            while (numCards > 1)
            {
                numCards--;
                numNext = randomNum.Next(numCards + 1);
                tempCard = _cards[numNext];
                _cards[numNext] = _cards[numCards];
                _cards[numCards] = tempCard;
            }
        }

        #endregion
    }

    public class WarDeck : Deck
    {
        #region Constructors / Methods

        public WarDeck()
        {
        }

        // Build one 52-card deck including card values for War.
        public override void Build()
        {
            foreach (var suit in PlayingCard.Suits)                             // Four Suits
                for (int i = 0; i < PlayingCard.Ranks.Length; i++)              // 13 Ranks & Corresponding/Incrementing Values
                    Cards.Add(new PlayingCard(suit, PlayingCard.Ranks[i], i));
        }

        // Deal the 52-card deck into equal (26-card) decks for two players.
        public (List<PlayingCard> deckA, List<PlayingCard> deckB) Deal()
        {
            var deckA = new List<PlayingCard>();
            var deckB = new List<PlayingCard>();

            for (int i = 0; i < Cards.Count; i += 2)
            {
                deckA.Add(Cards[i]);
                deckB.Add(Cards[i + 1]);
            }

            return (deckA, deckB);
        }

        #endregion
    }

    public class PlayerDeck : Deck
    {
        #region Fields / Properties

        private List<PlayingCard> _cardsInPlay = new List<PlayingCard>();

        public List<PlayingCard> CardsInPlay { get => _cardsInPlay; set => _cardsInPlay = value; }

        public PlayingCard CardInPlay
        {
            get
            {
                return CardsInPlay[CardsInPlay.Count - 1];
            }
        }

        #endregion

        #region Constructors / Methods

        public PlayerDeck()
        {

        }

        // Add a List of new cards to the player's deck.
        public void AddNewCards(List<PlayingCard> addCards)
        {
            foreach (var card in addCards)
                Cards.Add(card);
        }

        // Return the InPlay cards back to the player's deck.
        public bool ReturnInPlayCardsToDeck()
        {
            try
            {
                foreach (var card in CardsInPlay)
                    Cards.Add(card);

                CardsInPlay.Clear();

                return true;
            }
            catch
            {
                return false;
            }
        }

        // Remove the top (index 0) card from the deck and place it InPlay.
        public bool PlayTopCard(bool isFaceUp)
        {
            try
            {
                Cards[0].FaceUp = isFaceUp;

                CardsInPlay.Add(Cards[0]);

                Cards.Remove(Cards[0]);

                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion
    }
}