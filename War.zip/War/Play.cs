﻿/*+----------------------------------------------------------------------
 ||           Class Play
 ||
 ||         Author:  Kimberly Gillespie
 ||        Created:  July 9, 2019
 ||  Last Modified:  /
 ||   Modification:  /
 ||    
 ||        Purpose:  Start and run a game of War.
 ++-----------------------------------------------------------------------*/

namespace War
{
    class Play
    {
        public static void Main(string[] args)
        {
            Game War = new War();

            War.Start();

            System.Threading.Thread.Sleep(10000);
        }
    }
}
